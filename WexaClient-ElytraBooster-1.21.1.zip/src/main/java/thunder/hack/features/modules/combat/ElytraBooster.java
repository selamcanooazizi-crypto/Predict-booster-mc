package thunder.hack.features.modules.combat;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.util.math.Vec3d;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

/**
 * ElytraBooster - Fabric 1.21.1 (Yarn)
 * Elytra ile ucarken fisek (firework) basinca hizi kademeli olarak arttirir.
 * Modlar: BravoHvh (sabit orta hiz), Custom (1 - 15 arasi ayarlanabilir).
 */
public class ElytraBooster extends Module {

    public enum Mode { BravoHvh, Custom }

    // Moduldeki acip kapanan "Really" kutusu
    private final Setting<Boolean> really = new Setting<>("Really", true);
    private final Setting<Mode> mode = new Setting<>("Mode", Mode.BravoHvh);
    // Custom modunda 1 - 15 arasi
    private final Setting<Float> custom = new Setting<>("Custom", 1.5f, 1.0f, 15.0f);

    private float ramp = 0f; // 0..1 kademeli artis (ani siçrama olmasin)

    public ElytraBooster() {
        super("ElytraBooster", Category.COMBAT);
    }

    @Override
    public void onUpdate() {
        if (fullNullCheck() || !really.getValue()) return;

        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;

        if (!p.isFallFlying() || !hasOwnRocket(p)) {
            ramp = Math.max(0f, ramp - 0.2f); // firesek bitince yavasca birak
            return;
        }

        ramp = Math.min(1f, ramp + 1f / 8f); // ~8 tickte tam guc

        float mult = mode.getValue() == Mode.BravoHvh ? 2.2f : custom.getValue();
        if (mult <= 1.0f) return;

        // Tick basina eklenen ek hiz (vanilla firesek ~0.1)
        double boost = (mult - 1.0) * 0.04 * ramp;
        // Cok hizli olmasin: sert ust sinir (blok/tick)
        double maxSpeed = Math.min(1.7 + (mult - 1.0) * 0.1, 3.0);

        Vec3d v = p.getVelocity();
        if (v.length() >= maxSpeed) return;

        Vec3d look = p.getRotationVec(1.0f);
        p.setVelocity(v.add(look.multiply(boost)));
    }

    private boolean hasOwnRocket(ClientPlayerEntity p) {
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof FireworkRocketEntity fr && fr.getOwner() == p) return true;
        }
        return false;
    }
}
