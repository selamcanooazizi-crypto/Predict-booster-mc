package thunder.hack.features.modules.combat;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

/**
 * ElytraPredict (yeniden yazildi) - Fabric 1.21.1 (Yarn)
 * Orijinal public uyeler korundu: INSTANCE, overtakeDistance, track(), canPredict(), apply().
 * Hedef kacarken/suzulurken hizina bakip ONUNE gecen bir nokta dondurur.
 * Hedefin dibine girince gercek konumu dondurur (vurus icin).
 */
public class ElytraPredict extends Module {

    public final Setting<Float> overtakeDistance = new Setting<>("Overtake Distance", 5.0f, 0.0f, 12.0f);

    public static ElytraPredict INSTANCE;

    private int trackedId = -1;
    private double lx, ly, lz;   // son konum
    private double vx, vy, vz;   // yumusatilmis hiz (blok/tick)
    private long lastMs = 0L;
    private long disabledUntil = 0L;

    public ElytraPredict() {
        super("ElytraPredict", Category.COMBAT);
        INSTANCE = this;
    }

    public boolean canPredict(ClientPlayerEntity p) {
        long now = System.currentTimeMillis();
        if (p.isFallFlying()) disabledUntil = now + 300L;
        return now <= disabledUntil;
    }

    public void track(Entity e) {
        long now = System.currentTimeMillis();
        if (e.getId() != trackedId || now - lastMs > 500L) {
            trackedId = e.getId();
            lx = e.getX(); ly = e.getY(); lz = e.getZ();
            vx = vy = vz = 0;
            lastMs = now;
            return;
        }
        if (e.getX() == lx && e.getY() == ly && e.getZ() == lz) return; // ayni tick

        double ticks = Math.max(1.0, (now - lastMs) / 50.0);
        double nx = (e.getX() - lx) / ticks, ny = (e.getY() - ly) / ticks, nz = (e.getZ() - lz) / ticks;
        vx = vx * 0.5 + nx * 0.5; // hizli tepki
        vy = vy * 0.5 + ny * 0.5;
        vz = vz * 0.5 + nz * 0.5;
        lx = e.getX(); ly = e.getY(); lz = e.getZ();
        lastMs = now;
    }

    /** Aura'nin cagirdigi hook: (hedef nokta, hedef varlik) -> yeni hedef nokta */
    public static Object apply(Object posObj, Object entObj) {
        ElytraPredict m = INSTANCE;
        if (m == null || !m.isEnabled() || !(posObj instanceof Vec3d pos) || !(entObj instanceof Entity target))
            return posObj;

        ClientPlayerEntity me = mc.player;
        if (me == null) return posObj;

        m.track(target);
        if (!m.canPredict(me)) return posObj;

        double speed = Math.sqrt(m.vx * m.vx + m.vy * m.vy + m.vz * m.vz);
        if (speed < 0.05) return posObj; // hedef durgun

        Vec3d eye = me.getEyePos();
        double dist = eye.distanceTo(pos);

        // Dibine girince: gercek konum, boylece vurus atilir
        if (dist < 2.8) return posObj;

        Vec3d dir = new Vec3d(m.vx, m.vy, m.vz).multiply(1.0 / speed);
        double mySpeed = Math.max(me.getVelocity().length(), 0.5);

        // Yakalama suresi (tick): mesafe / benim hizim
        double t = MathHelper.clamp(dist / mySpeed, 0.0, 20.0);

        double over = m.overtakeDistance.getValue() * MathHelper.clamp(speed / 0.6, 0.3, 1.0);
        // Yaklastikca onune gecme mesafesi azalir; boylece onunde bekleyip kalmaz
        over *= MathHelper.clamp((dist - 2.8) / 6.0, 0.0, 1.0);

        Vec3d lead = new Vec3d(m.vx * t, m.vy * t, m.vz * t);
        return pos.add(lead).add(dir.multiply(over));
    }
}
