Kurulum (kaynak projede):
1) ElytraBooster.java ve ElytraPredict.java -> src/main/java/thunder/hack/features/modules/combat/
   (ElytraPredict.java mevcut dosyanin yerine gecer)
2) Modul listesine otomatik eklenmiyorsa ModuleManager'a  new ElytraBooster()  ekle
3) GitHub Actions ile derle. Hata cikarsa derleme logunu yolla.
