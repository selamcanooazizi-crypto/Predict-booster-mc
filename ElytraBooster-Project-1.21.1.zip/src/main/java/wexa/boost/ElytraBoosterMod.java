package wexa.boost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class ElytraBoosterMod implements ClientModInitializer {

    private static boolean enabled = true;      // "Really"
    private static boolean custom = false;      // false = BravoHvh, true = Custom
    private static float customValue = 1.5f;    // 1 - 15
    private static float ramp = 0f;

    private static KeyBinding toggleKey, modeKey, upKey, downKey;

    @Override
    public void onInitializeClient() {
        String cat = "ElytraBooster";
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("Really (ac/kapat)", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, cat));
        modeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("Mod: BravoHvh / Custom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_N, cat));
        upKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("Custom +", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_BRACKET, cat));
        downKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("Custom -", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET, cat));

        ClientTickEvents.END_CLIENT_TICK.register(ElytraBoosterMod::tick);
    }

    private static void msg(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), true);
    }

    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;

        while (toggleKey.wasPressed()) { enabled = !enabled; msg(mc, "Really: " + (enabled ? "ACIK" : "KAPALI")); }
        while (modeKey.wasPressed()) { custom = !custom; msg(mc, "ElytraBooster mod: " + (custom ? "Custom " + customValue : "BravoHvh")); }
        while (upKey.wasPressed()) { customValue = Math.min(15f, Math.round((customValue + 0.5f) * 2f) / 2f); msg(mc, "Custom: " + customValue); }
        while (downKey.wasPressed()) { customValue = Math.max(1f, Math.round((customValue - 0.5f) * 2f) / 2f); msg(mc, "Custom: " + customValue); }

        if (!enabled) return;

        ClientPlayerEntity p = mc.player;
        if (!p.isFallFlying() || !hasOwnRocket(mc, p)) {
            ramp = Math.max(0f, ramp - 0.2f);
            return;
        }
        ramp = Math.min(1f, ramp + 1f / 8f);

        float mult = custom ? customValue : 2.2f;
        if (mult <= 1.0f) return;

        double boost = (mult - 1.0) * 0.04 * ramp;
        double maxSpeed = Math.min(1.7 + (mult - 1.0) * 0.1, 3.0);

        Vec3d v = p.getVelocity();
        if (v.length() >= maxSpeed) return;
        p.setVelocity(v.add(p.getRotationVec(1.0f).multiply(boost)));
    }

    private static boolean hasOwnRocket(MinecraftClient mc, ClientPlayerEntity p) {
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof FireworkRocketEntity fr && fr.getOwner() == p) return true;
        }
        return false;
    }
}
